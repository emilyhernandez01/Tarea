-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-06-2024 a las 06:10:39
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdproductos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_movimientos`
--

CREATE TABLE `tbl_movimientos` (
  `Id_movimiento` int(11) NOT NULL,
  `Id_producto` int(11) NOT NULL,
  `Fecha_movimiento` date NOT NULL,
  `Tipo_movimiento` enum('entrada','salida') NOT NULL,
  `Cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_movimientos`
--

INSERT INTO `tbl_movimientos` (`Id_movimiento`, `Id_producto`, `Fecha_movimiento`, `Tipo_movimiento`, `Cantidad`) VALUES
(1, 1, '2024-06-15', 'entrada', 3),
(2, 2, '2024-06-27', 'salida', 5),
(3, 1, '2024-06-15', 'entrada', 2),
(4, 1, '2024-06-15', 'entrada', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `Id_producto` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `Descripcion` text NOT NULL,
  `Precio_costo` decimal(10,2) NOT NULL,
  `Precio_venta` decimal(10,2) NOT NULL,
  `Stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`Id_producto`, `Nombre`, `Descripcion`, `Precio_costo`, `Precio_venta`, `Stock`) VALUES
(1, 'agua', 'no', 35.00, 42.00, 13),
(2, 'Malteada', 'Fresa', 20.00, 30.00, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_movimientos`
--
ALTER TABLE `tbl_movimientos`
  ADD PRIMARY KEY (`Id_movimiento`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`Id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_movimientos`
--
ALTER TABLE `tbl_movimientos`
  MODIFY `Id_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `Id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
