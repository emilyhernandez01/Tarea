<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <link rel="stylesheet" type="text/css" href="bp-local/css/bootstrap.min.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Productos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registro_de_productos.php">Registrar Productos</a></li>
            <li><a class="dropdown-item" href="listar.php">Listado de Productos</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Movimientos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="movimientos.php">Registro de Movimiento</a></li>
            <li><a class="dropdown-item" href="verlistademovimiento.php">Lista de Movimientos</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<center><hr><h1>Registro de Productos</h1><hr></center>
  <div class="row my-5" >
    <center>
      <div class="col col-md-6 col-sm-12 col-lg-10">
      <form action="" method="POST" class="row g-3" >
   <div class="col-md-6  my-4">
    <label for="inputEmail4" class="form-label" style="float:left">Id_Producto</label>
    <input type="text" class="form-control"  id="Id_producto" name="Id_producto" >
  </div>
   <div class="col-md-6 my-4">
    <label for="inputEmail4" class="form-label" style="float:left">Nombre del Producto</label>
    <input type="text" class="form-control"  id="Nombre" name="Nombre" >
  </div>
  <div class="mb-3">
   <label for="productDescription" class="form-label">Descripción</label>
    <textarea class="form-control" id="Descripcion" name="Descripcion" rows="3"></textarea>
  </div>
  <div class="col-md-6 col-lg-6 my-4">
    <label for="inputPassword4" class="form-label" style="float:left">Precio de Costo</label>
    <input type="text" class="form-control" id="Precio_costo" name="Precio_costo" >
  </div>
  <div class="col-md-6 col-lg-6  my-4">
    <label for="inputPassword4" class="form-label" style="float:left">Precio de Venta</label>
     <input type="text" class="form-control" id="Precio_Venta" name="Precio_Venta" >
  </div>
  <div class="col-md-6 col-lg-12  my-4">
    <label for="inputPassword4" class="form-label" style="float:left">Stock</label>
     <input type="text" class="form-control" id="Stock" name="Stock" >
  </div>
  <div class="col-12  my-3">
    <button type="submit" class="btn btn-primary w-100" name="submit" >Registrar Producto</button>
    <br><br>
  </div>
</form>
    </div>
    </center>
  </div>
  <div class="container text-danger text-center"></div>
    <?php 
    if($_SERVER['REQUEST_METHOD']==='POST'){
      if(empty($_POST['Id_producto']) && strlen($_POST['Id_producto']) < 5){
        echo "<p>El codigo del producto ess requerido</p>";
      }

      if(empty($_POST['Nombre']) && strlen($_POST['Nombre']) < 5){
        echo "<p>El Nombre del producto es requerido</p>";
      }

      if(empty($_POST['Precio_costo']) && strlen($_POST['Precio_costo']) < 5){
        echo "<p>El Precio de costo es requerido</p>";
      }

      if(empty($_POST['Precio_Venta']) && strlen($_POST['Precio_Venta']) < 5){
        echo "<p>El precio de venta es requerido</p>";
      }

      if(empty($_POST['Stock']) && strlen($_POST['Stock']) < 5){
        echo "<p>Stock es requerido</p>";
      }

      if(empty($_POST['Descripcion'])){
        echo "<p>Descripcion no debe estar vacio</p>";
      }
    }
    include ("conexion.php");
    include ("registrar.php");



     ?>
   
  </div>

  <script src="bp-local/js/bootstrap.bundle.min.js"></script>
</body>
</html>