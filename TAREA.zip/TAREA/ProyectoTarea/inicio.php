<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" type="text/css" href="bp-local/css/bootstrap.min.css">
	<title>Registro de Productos</title>
</head>
<body>

  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Productos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registro_de_productos.php">Registrar Productos</a></li>
            <li><a class="dropdown-item" href="listar.php">Listado de Productos</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Movimientos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="movimientos.php">Registro de Movimiento</a></li>
            <li><a class="dropdown-item" href="verlistademovimiento.php">Lista de Movimientos</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<br><br>
  <div class="container">
    <div class="card" style="width: 18rem;">
  <img src="https://s1.elespanol.com/2019/09/09/ciencia/nutricion/queso-queso_azul-nutricion_427969266_134213435_1706x960.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Queso</h5>
  </div>
  <div class="card" style="width: 18rem;">
  <img src="https://thefoodtech.com/wp-content/uploads/2022/09/margarina-828x548.jpeg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Mantequilla</h5>
  </div>
</div>
<div class="card" style="width: 18rem;">
  <img src="https://phantom-marca.unidadeditorial.es/1a3ec527308f8fb83d8cee1b776e27bf/resize/828/f/jpg/assets/multimedia/imagenes/2023/05/28/16852678640468.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Leche</h5>
  </div>
</div>
</div>

  </div>
  <div class="container">
    <div class="card" style="width: 18rem;">
  <img src="https://www.recetasnestlecam.com/sites/default/files/styles/crop_article_banner_desktop_nes/public/2023-02/cuenco-con-yogurt-griego.jpg%20banner%20desktop.jpg?itok=jXAQUTrv" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Yougurt</h5>
  </div>
</div>
<div class="card" style="width: 18rem;">
  <img src="https://i.ytimg.com/vi/QP56t4Dav0M/maxresdefault.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Cuajada</h5>
  </div>
</div>
<div class="card" style="width: 18rem;">
  <img src="https://cdn7.kiwilimon.com/recetaimagen/3666/10613.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Malteada</h5>
  </div>
</div>
  </div>
  <script src="bp-local/js/bootstrap.bundle.min.js"></script>
</body>
</html>