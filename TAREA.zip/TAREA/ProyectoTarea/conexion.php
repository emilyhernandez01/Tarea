<?php
	
	$nombrehost = "localhost"; 
	$nombreuser = "root";
	$contraseña = "";
	$nombredb = "bdproductos";

	$conexion = mysqli_connect($nombrehost, $nombreuser, $contraseña, $nombredb);

	if (!$conexion) {
		echo "Fallo la Conexion";
	}

 ?>