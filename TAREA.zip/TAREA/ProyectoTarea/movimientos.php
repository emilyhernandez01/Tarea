<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="bp-local/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <title>Registro de Movimiento</title>
</head>
<body>

          <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Productos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="registro_de_productos.php">Registrar Productos</a></li>
            <li><a class="dropdown-item" href="listar.php">Listado de Productos</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Movimientos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="movimientos.php">Registro de Movimiento</a></li>
            <li><a class="dropdown-item" href="verlistademovimiento.php">Lista de Movimientos</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
    <center>
        <div class="container">
          <hr>
            <h2>Registro de movimientos</h2>
            <hr>
        <form action="procesar_movimiento.php" method="post">
        <div class="col-12  my-3">
          <label for="id_producto"><center><strong>ID Producto:</strong></center></label>
        <br><br>
        <input class="form-control" type="number" id="id_producto" name="id_producto" required style="width: 500px; height: 30px; border-radius: 5px;">
        </div>
        <div class="col-12  my-3">
          <label for="tipo_movimiento"><strong>Tipo Movimiento:</strong></label>
        <br><br>
        <select  class="form-control" type="text" id="tipo_movimiento" name="tipo_movimiento" required style="width: 500px; height: 30px; border-radius: 5px;">
            <option>Entrada</option>
            <option>Salida</option>
        </select>
        </div>
        <div class="col-12  my-3">
          <label for="cantidad"><strong>Cantidad:</strong></label>
          <br><br>
        <input class="form-control" type="number" id="cantidad" name="cantidad" required style="width: 500px; height: 30px; border-radius: 5px;">
        </div>
        
        <div class="col-12  my-3">
          <label for="fecha_movimiento"><strong>Fecha Movimiento:</strong></label>
          <br><br>
        <input class="form-control" type="date" id="fecha_movimiento" name="fecha_movimiento" required style="width: 500px; height: 30px; border-radius: 5px;">
        </div>
        <br><br>
        <div class="col-12  my-3">
    <button type="submit" value="Registrar Movimiento" class="btn btn-primary w-50" name="submit" >Registrar Movimiento</button>
    <br>
  </div>
        
    </form>

    </div>
    
    </center>
    
  <script src="bp-local/js/bootstrap.bundle.min.js"></script>
</body>
</html>